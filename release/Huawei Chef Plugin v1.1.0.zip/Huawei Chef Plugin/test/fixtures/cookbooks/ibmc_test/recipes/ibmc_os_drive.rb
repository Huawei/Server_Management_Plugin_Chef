ibmc_drive 'get' do
  action :get
end
