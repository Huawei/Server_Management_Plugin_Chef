ibmc_ethernet_ipv6 'set ipv6' do
  origin 'Static'
  action :set
end
