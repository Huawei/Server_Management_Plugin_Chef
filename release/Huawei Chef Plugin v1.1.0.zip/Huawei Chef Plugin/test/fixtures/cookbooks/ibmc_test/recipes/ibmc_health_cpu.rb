ibmc_health_cpu 'get' do
  action :get
end
