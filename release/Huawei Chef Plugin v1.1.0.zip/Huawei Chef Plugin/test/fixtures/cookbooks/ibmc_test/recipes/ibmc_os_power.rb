ibmc_sys_power 'set os power' do
  reset_type 'On'
  action :set
end
