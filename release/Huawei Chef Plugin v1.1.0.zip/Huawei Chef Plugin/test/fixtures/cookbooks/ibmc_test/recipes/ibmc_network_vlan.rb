ibmc_ethernet_vlan 'set vlan' do
  enabled true
  id 2000
  action :set
end
