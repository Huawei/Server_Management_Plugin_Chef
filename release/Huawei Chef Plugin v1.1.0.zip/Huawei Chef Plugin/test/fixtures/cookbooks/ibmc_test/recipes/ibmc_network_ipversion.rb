ibmc_ethernet_ipversion 'set ipversion' do
  version 'IPv4AndIPv6'
  action :set
end
