## 1.0.0
Initial release. Add Chef resources to config HUAWEI iBMC using iBMC REST API.
